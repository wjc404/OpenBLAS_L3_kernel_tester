﻿//gcc -DGEMM_INT=int -DBLASLONG=long -fopenmp strmm_kernel_tester.c -Wl,--start-group /home/wang/intel-mkl/mkl/lib/intel64/libmkl_intel_lp64.a /home/wang/intel-mkl/mkl/lib/intel64/libmkl_gnu_thread.a /home/wang/intel-mkl/mkl/lib/intel64/libmkl_core.a -Wl,--end-group -lpthread -lm -ldl -o strmm_kernel_tester
#define FLOAT float
#define GEMM sgemm_

extern void GEMM(char *tra,char *trb,GEMM_INT *m,GEMM_INT *n,GEMM_INT *k,FLOAT *alpha,FLOAT *A,GEMM_INT *lda,FLOAT *B,GEMM_INT *ldb,FLOAT *beta,FLOAT *C,GEMM_INT *ldc);
static void GEMM_WRAPPER(char transa,char transb,BLASLONG m,BLASLONG n,BLASLONG k,FLOAT alpha,FLOAT *A,BLASLONG lda,FLOAT *B,BLASLONG ldb,FLOAT beta,FLOAT *C,BLASLONG ldc){
  GEMM_INT M=m, N=n, K=k, LDA=lda, LDB=ldb, LDC=ldc;
  char TRANSA=transa, TRANSB=transb;
  FLOAT ALPHA=alpha, BETA=beta;
  GEMM(&TRANSA,&TRANSB,&M,&N,&K,&ALPHA,A,&LDA,B,&LDB,&BETA,C,&LDC);
}

#define COMPUTE_LN(a_copy,b_copy) {\
  aa = a + m_count * k;\
  cc = ch + m_count;\
  if (k - kk >= 0)\
    GEMM_WRAPPER('N','T',a_copy,b_copy,k - (kk-a_copy),alpha,aa + a_copy * (kk-a_copy),a_copy,bh + b_copy * (kk-a_copy),b_copy,0.0,cc,ldc);\
  kk -= a_copy;\
}
//offset>=0; offset+m<=k.
static void TRMM_KERNEL_REF_LN(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N){
  BLASLONG i, j; FLOAT *aa, *cc, *bh, *ch; BLASLONG kk,m_count;
  j = n / GEMM_UNROLL_N;
  bh = b; ch = c;
  while (j > 0) {
    kk = m + offset; m_count = m;
    for (i = 1; i < GEMM_UNROLL_M; i *= 2)
      if (m & i) {m_count -= i; COMPUTE_LN(i,GEMM_UNROLL_N)}
    for(i=m/GEMM_UNROLL_M;i>0;i--) {
      m_count -= GEMM_UNROLL_M;
      COMPUTE_LN(GEMM_UNROLL_M,GEMM_UNROLL_N)
    }
    bh += GEMM_UNROLL_N * k;
    ch += GEMM_UNROLL_N * ldc;
    j --;
  }
  if (n % GEMM_UNROLL_N > 0) {
    j = (GEMM_UNROLL_N >> 1);
    while (j > 0) {
      if (n & j) {
        kk = m + offset; m_count = m;
        for (i = 1; i < GEMM_UNROLL_M; i *= 2)
          if (m & i) {m_count -= i; COMPUTE_LN(i,j)}
        for(i=m/GEMM_UNROLL_M;i>0;i--){
          m_count -= GEMM_UNROLL_M;
          COMPUTE_LN(GEMM_UNROLL_M,j)
        }
        bh += j * k;
        ch += j * ldc;
      }
      j = (j>>1);
    }
  }
}

#define COMPUTE_LT(a_copy,b_copy) {\
  aa = a + m_count * k;\
  cc = ch + m_count;\
  if (kk >= 0)\
    GEMM_WRAPPER('N','T',a_copy, b_copy, kk+a_copy, alpha, aa, a_copy, bh, b_copy, 0.0, cc, ldc);\
  kk += a_copy;\
}
static void TRMM_KERNEL_REF_LT(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N){
  FLOAT *aa, *cc, *bh, *ch; BLASLONG kk, m_count; BLASLONG i, j;
  bh = b; ch = c;
  j = n / GEMM_UNROLL_N;
  while (j > 0) {
    kk = offset; m_count = 0;
    i = m / GEMM_UNROLL_M;
    while (i > 0) {
      COMPUTE_LT(GEMM_UNROLL_M,GEMM_UNROLL_N)
      m_count += GEMM_UNROLL_M;
      i --;
    }
    if (m % GEMM_UNROLL_M > 0) {
      i = GEMM_UNROLL_M >> 1;
      while (i > 0) {
        if (m & i) {COMPUTE_LT(i,GEMM_UNROLL_N) m_count += i;}
        i = i >> 1;
      }
    }
    bh += GEMM_UNROLL_N * k;
    ch += GEMM_UNROLL_N * ldc;
    j --;
  }
  if (n % GEMM_UNROLL_N > 0) {
    j = GEMM_UNROLL_N >> 1;
    while (j > 0) {
      if (n & j) {
        kk = offset; m_count = 0;
        i = m / GEMM_UNROLL_M;
        while (i > 0) {
          COMPUTE_LT(GEMM_UNROLL_M,j)
          m_count += GEMM_UNROLL_M;
          i --;
        }
        if (m % GEMM_UNROLL_M > 0) {
          i = GEMM_UNROLL_M >> 1;
          while (i > 0) {
            if (m & i) {COMPUTE_LT(i,j) m_count += i;}
            i = i >> 1;
          }
        }
        bh += j * k;
        ch += j * ldc;
      }
      j = j >> 1;
    }
  }
}

#define COMPUTE_RN(a_copy,b_copy) {\
  aa = a + m_count * k;\
  cc = ch + m_count;\
  if (kk >= 0)\
    GEMM_WRAPPER('N','T',a_copy, b_copy, kk+b_copy, alpha, aa, a_copy, bh, b_copy, 0.0, cc, ldc);\
}
//-offset>=0;n-offset<=k.
static void TRMM_KERNEL_REF_RN(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N){
  FLOAT *aa, *cc, *bh, *ch;
  BLASLONG kk, m_count;
  BLASLONG i, j;
  j = n / GEMM_UNROLL_N;
  kk = -offset; bh = b; ch = c;
  while (j > 0) {
    m_count = 0;
    i = m / GEMM_UNROLL_M;
    if (i > 0) {
      do {
        COMPUTE_RN(GEMM_UNROLL_M,GEMM_UNROLL_N)
        m_count += GEMM_UNROLL_M;
        i --;
      } while (i > 0);
    }
    if (m % GEMM_UNROLL_M > 0) {
      i = GEMM_UNROLL_M >> 1;
      while (i > 0) {
        if (m & i) {COMPUTE_RN(i,GEMM_UNROLL_N) m_count += i;}
        i = i >> 1;
      }
    }
    kk += GEMM_UNROLL_N;
    bh += GEMM_UNROLL_N * k;
    ch += GEMM_UNROLL_N * ldc;
    j --;
  }
  if (n % GEMM_UNROLL_N > 0) {
    j = GEMM_UNROLL_N >> 1;
    while (j > 0) {
      if (n & j) {
        m_count = 0;
        i = m / GEMM_UNROLL_M;
        while (i > 0) {
          COMPUTE_RN(GEMM_UNROLL_M,j)
          m_count += GEMM_UNROLL_M;
          i --;
        }
        if (m % GEMM_UNROLL_M > 0) {
          i = GEMM_UNROLL_M >> 1;
          while (i > 0) {
            if (m & i) {COMPUTE_RN(i,j) m_count += i;}
            i = i >> 1;
          }
        }
        bh += j * k;
        ch += j * ldc;
        kk += j;
      }
      j = j >> 1;
    }
  }
}

#define COMPUTE_RT(a_copy,b_copy) {\
  aa = a + m_count * k;\
  cc = ch + m_count;\
  if (k - kk >= 0)\
    GEMM_WRAPPER('N','T',a_copy, b_copy, k - (kk-b_copy), alpha, aa + (kk-b_copy) * a_copy, a_copy, bh + (kk-b_copy) * b_copy, b_copy, 0.0, cc, ldc);\
}
static void TRMM_KERNEL_REF_RT(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N){
  BLASLONG i, j;
  FLOAT *aa, *cc, *bh, *ch;
  BLASLONG kk, m_count;
  kk = n - offset;
  ch = c + n * ldc;
  bh = b + n * k;
  if (n % GEMM_UNROLL_N > 0) {
    j = 1;
    while (j < GEMM_UNROLL_N) {
      if (n & j) {
        m_count = 0;
        bh -= j * k;
        ch -= j * ldc;
        i = m / GEMM_UNROLL_M;
        if (i > 0) {
          do {
            COMPUTE_RT(GEMM_UNROLL_M,j)
            m_count += GEMM_UNROLL_M;
            i --;
          } while (i > 0);
        }
        if (m % GEMM_UNROLL_M > 0) {
          i = GEMM_UNROLL_M >> 1;
          do {
            if (m & i) {
              COMPUTE_RT(i,j)
              m_count += i;
            }
            i = i >> 1;
          } while (i > 0);
        }
        kk -= j;
      }
      j = j << 1;
    }
  }
  j = n / GEMM_UNROLL_N;
  if (j > 0) {
    do {
      m_count = 0;
      bh -= GEMM_UNROLL_N * k;
      ch -= GEMM_UNROLL_N * ldc;
      i = m / GEMM_UNROLL_M;
      if (i > 0) {
        do {
          COMPUTE_RT(GEMM_UNROLL_M,GEMM_UNROLL_N)
          m_count += GEMM_UNROLL_M;
          i --;
        } while (i > 0);
      }
      if (m % GEMM_UNROLL_M > 0) {
        i = GEMM_UNROLL_M >> 1;
        do {
          if (m & i) {
            COMPUTE_RT(i,GEMM_UNROLL_N)
            m_count += i;
          }
          i = i >> 1;
        } while (i > 0);
      }
      kk -= GEMM_UNROLL_N;
      j --;
    } while (j > 0);
  }
}

#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#define DTOL 1.0e-4
static void TRMM_COMPARE_KERNEL(void (*trmm_kernel_ref)(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N), int (*trmm_kernel_tested)(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset), FLOAT *A0, FLOAT *Ar, FLOAT *At, FLOAT *B0, FLOAT *Br, FLOAT *Bt, FLOAT *C0, FLOAT *Cr, FLOAT *Ct, BLASLONG m, BLASLONG n, BLASLONG k, BLASLONG offset, BLASLONG ldc, FLOAT *maxdiff_a, FLOAT *maxdiff_b, FLOAT *maxdiff_c, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N){
  BLASLONG i,j; FLOAT alpha=2.0, mda=0.0, mdb=0.0, mdc=0.0, tmp=0.0;
  for(i=0;i<n;i++){
    memcpy((char *)(Cr+i*ldc),(char *)(C0+i*ldc),ldc*sizeof(FLOAT));
    memcpy((char *)(Ct+i*ldc),(char *)(C0+i*ldc),ldc*sizeof(FLOAT));
  }
  for(i=0;i<k;i++){
    memcpy((char *)(Ar+i*m),(char *)(A0+i*m),m*sizeof(FLOAT));
    memcpy((char *)(At+i*m),(char *)(A0+i*m),m*sizeof(FLOAT));
    memcpy((char *)(Br+i*n),(char *)(B0+i*n),n*sizeof(FLOAT));
    memcpy((char *)(Bt+i*n),(char *)(B0+i*n),n*sizeof(FLOAT));
  }
  (*trmm_kernel_ref)(m,n,k,alpha,Ar,Br,Cr,ldc,offset,GEMM_UNROLL_M,GEMM_UNROLL_N);
  (*trmm_kernel_tested)(m,n,k,alpha,At,Bt,Ct,ldc,offset);
  for(i=0;i<n;i++){
    for(j=0;j<ldc;j++){
      tmp = (FLOAT)fabs((double)Ct[i*ldc+j]-(double)Cr[i*ldc+j]);
      if(tmp>DTOL) printf("Element pair from C matrices at m_pos=%3ld and n_pos=%3ld, diff %.2e, Ct=%.2e, Cr=%.2e\n",j,i,tmp,Ct[i*ldc+j],Cr[i*ldc+j]);
      if(tmp>mdc) mdc=tmp;
    }
  }
  if(mdc>DTOL) printf("TRMM call with m=%3ld, n=%3ld, k=%3ld and offset=%3ld failed with output matrix C.\n\n",m,n,k,offset);
  for(i=0;i<k;i++){
    for(j=0;j<m;j++){
      tmp = (FLOAT)fabs((double)At[i*m+j]-(double)Ar[i*m+j]);
      if(tmp>DTOL) printf("Element pair from A matrices at pos %3ld, diff %.2e\n",i*m+j,tmp);
      if(tmp>mda) mda=tmp;
    }
    for(j=0;j<n;j++){
      tmp = (FLOAT)fabs((double)Bt[i*n+j]-(double)Br[i*n+j]);
      if(tmp>DTOL) printf("Element pair from B matrices at pos %3ld, diff %.2e\n",i*n+j,tmp);
      if(tmp>mdb) mdb=tmp;
    }
  }
  if(mda>DTOL) printf("TRMM call with m=%3ld, n=%3ld, k=%3ld and offset=%3ld failed with output matrix A.\n\n",m,n,k,offset);
  if(mdb>DTOL) printf("TRMM call with m=%3ld, n=%3ld, k=%3ld and offset=%3ld failed with output matrix B.\n\n",m,n,k,offset);
  *maxdiff_a=mda; *maxdiff_b=mdb; *maxdiff_c=mdc;
}
#include <time.h>
#include <dlfcn.h>
int main(int argc, char* argv[]){ // command line: ./strmm_kernel_test [side] [transa] [gemm_unroll_m] [gemm_unroll_n]
  FLOAT *A0,*Ar,*At,*B0,*Br,*Bt,*C0,*Cr,*Ct; FLOAT diffa,diffb,diffc;
  void (*trmm_kernel_ref)(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset, BLASLONG GEMM_UNROLL_M, BLASLONG GEMM_UNROLL_N);
  int (*trmm_kernel_tested)(BLASLONG m, BLASLONG n, BLASLONG k, FLOAT alpha, FLOAT *a, FLOAT *b, FLOAT *c, BLASLONG ldc, BLASLONG offset); 
  char *DLERR; void *handle;
  char openblaspath[200]; char funcname[] = "strmm_kernel_XX"; char side,transa;
  BLASLONG m_max=50, n_max=50, k=100, ldc=80; BLASLONG off_min,off_max,i,j,t,GEMM_UNROLL_M,GEMM_UNROLL_N;
  if (argc >= 2) side = *argv[1];
  else side = 'L';
  if (side != 'L' && side != 'l') side = 'R';
  else side = 'L';
  if (argc >= 3) transa = *argv[2];
  else transa = 'N';
  if (transa != 'N' && transa != 'n') transa = 'T';
  else transa = 'N';
  if (argc >= 4) GEMM_UNROLL_M = atoi(argv[3]);
  else GEMM_UNROLL_M = 8;
  if (argc >= 5) GEMM_UNROLL_N = atoi(argv[4]);
  else GEMM_UNROLL_N = 4;
  for(i=1;i<=GEMM_UNROLL_M/2;i<<=1); GEMM_UNROLL_M = i;
  for(i=1;i<=GEMM_UNROLL_N/2;i<<=1); GEMM_UNROLL_N = i;
  funcname[13] = side; funcname[14] = transa;
  if(side=='L' && transa=='N') trmm_kernel_ref = &TRMM_KERNEL_REF_LN;
  if(side=='L' && transa=='T') trmm_kernel_ref = &TRMM_KERNEL_REF_LT;
  if(side=='R' && transa=='N') trmm_kernel_ref = &TRMM_KERNEL_REF_RN;
  if(side=='R' && transa=='T') trmm_kernel_ref = &TRMM_KERNEL_REF_RT;

// load openblas library
  dlerror();
  printf("Please enter the OpenBLAS library path(path to the *.so file):");
  scanf("%s",openblaspath);
  handle = dlopen(openblaspath,RTLD_LAZY);
  DLERR = dlerror();
  if(DLERR){printf ("Error linking the OpenBLAS library: %s\n",DLERR); exit(1);}
  trmm_kernel_tested = dlsym(handle,funcname);
  DLERR = dlerror();
  if (DLERR) {
    printf ("Error locating strmm kernel function in the OpenBLAS library: %s\n",DLERR);
    trmm_kernel_tested=NULL;dlclose(handle);handle=NULL;exit(1);
  }
  printf("Start TRMM kernel test with GEMM_UNROLL_M=%ld, GEMM_UNROLL_N=%ld, function_name=%s\n",GEMM_UNROLL_M,GEMM_UNROLL_N,funcname);

  A0 = (FLOAT *)malloc(m_max*k*sizeof(FLOAT));
  Ar = (FLOAT *)malloc(m_max*k*sizeof(FLOAT));
  At = (FLOAT *)malloc(m_max*k*sizeof(FLOAT));
  B0 = (FLOAT *)malloc(n_max*k*sizeof(FLOAT));
  Br = (FLOAT *)malloc(n_max*k*sizeof(FLOAT));
  Bt = (FLOAT *)malloc(n_max*k*sizeof(FLOAT));
  C0 = (FLOAT *)malloc(n_max*ldc*sizeof(FLOAT));
  Cr = (FLOAT *)malloc(n_max*ldc*sizeof(FLOAT));
  Ct = (FLOAT *)malloc(n_max*ldc*sizeof(FLOAT));
  srand(time(NULL));
  for(i=0;i<m_max*k;i++) A0[i] = (FLOAT)rand() / (FLOAT)RAND_MAX * 2.0 - 1.0;
  for(i=0;i<n_max*k;i++) B0[i] = (FLOAT)rand() / (FLOAT)RAND_MAX * 2.0 - 1.0;
  for(i=0;i<n_max*ldc;i++) C0[i] = (FLOAT)rand() / (FLOAT)RAND_MAX * 2.0 - 1.0;

  for(i=1;i<=m_max;i++){
    for(j=1;j<=n_max;j++){
      if(side=='L'){off_min = 0; off_max = k-i;}
      else{off_min = j-k; off_max = 0;}
      for(t=off_min;t<=off_max;t++){
        TRMM_COMPARE_KERNEL(trmm_kernel_ref,trmm_kernel_tested,A0,Ar,At,B0,Br,Bt,C0,Cr,Ct,i,j,k,t,ldc,&diffa,&diffb,&diffc,GEMM_UNROLL_M,GEMM_UNROLL_N);
        if(diffa>DTOL || diffb>DTOL || diffc>DTOL) {i=m_max+1;j=n_max+1;t=off_max+1;}
      }
    }
  }

  if(diffa>DTOL || diffb>DTOL || diffc>DTOL) printf("Test failed with KERNEL_%c%c.\n",side,transa);
  else printf("Test passed with KERNEL_%c%c.\n",side,transa);
//unload openblas library
  trmm_kernel_tested=NULL; dlclose(handle); DLERR = dlerror(); handle=NULL;
  if(DLERR){
    printf ("Error in closing OpenBLAS:%s\n",DLERR);
    free(A0); free(Ar); free(At); free(B0); free(Br); free(Bt); free(C0); free(Cr); free(Ct); A0=Ar=At=B0=Br=Bt=C0=Cr=Ct=NULL;
    exit(1);
  }
  free(A0); free(Ar); free(At); free(B0); free(Br); free(Bt); free(C0); free(Cr); free(Ct); A0=Ar=At=B0=Br=Bt=C0=Cr=Ct=NULL;
  return 0;
}



